module.exports = {
    publicPath: '/firework-generator/',
    outputDir: 'firework-generator',
    pwa: {
        iconPaths: {
            faviconSVG: './favicon.ico',
            favicon32: './favicon.ico',
            favicon16: './favicon.ico',
            appleTouchIcon: './favicon.ico',
            maskIcon: './favicon.ico',
            msTileImage: './favicon.ico'
        }
    },
    devServer: {
        proxy: {
            '/api': {
                target: 'http://116.63.36.119:8848',
                changeOrigin: true,
                ws: true,
                pathRewrite: {
                    '^/api': ''
                }
            }
        }
    }
}