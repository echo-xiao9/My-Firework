import Vue from "vue";
import Vuex from "vuex";

Vue.use(Vuex)

const state = {
    hasCheckAuth: false,
    username: '',
    publicKey: '',
    isRoot: false,
}

const mutations = {
    mutationsSetHasCheckAuth(state, hasCheckAuth) {
        state.hasCheckAuth = hasCheckAuth
    },
    mutationsSetUsername(state, username) {
        state.username = username
    },
    mutationsSetPublicKey(state, publicKey) {
        state.publicKey = publicKey
    },
    mutationsSetIsRoot(state, isRoot) {
        state.isRoot = isRoot
    },
}

const getters = {
    getHasCheckAuth() {
        return state.hasCheckAuth
    },
    getUsername() {
        return state.username
    },
    getPublicKey() {
        return state.publicKey
    },
    getIsRoot() {
        return state.isRoot
    },
}

export default new Vuex.Store({
    state,
    mutations,
    getters,
})