import Vue from 'vue'
import '../theme/index.css'
import ElementUI from 'element-ui'
import App from './App.vue'
import VueRouter from 'vue-router'
import router from "@/router";
import store from './store/index'
import Axios from 'axios'

Vue.use(VueRouter)
Vue.use(ElementUI)
Vue.config.productionTip = false

Axios.defaults.withCredentials = true
Vue.prototype.$axios = Axios
Vue.prototype.$checkAuth = async function () {
  let {data} = await this.$axios.post(
      '/CheckSession'
  )
  if (data['status'] === 0) {
    this.$store.commit('mutationsSetHasCheckAuth', true)
    this.$store.commit('mutationsSetUsername', data['value']['username'])
    this.$store.commit("mutationsSetIsRoot", data['value']['isRoot'])
  }
  else {
    this.$store.commit('mutationsSetHasCheckAuth', true)
    this.$store.commit('mutationsSetPublicKey', data['value'])
  }
}

// Axios.defaults.baseURL = '/api'
Axios.defaults.baseURL = 'http://116.63.36.119:8848'

new Vue({
  render: h => h(App),
  router,
  store
}).$mount('#app')
