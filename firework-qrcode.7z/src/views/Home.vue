<template>
  <div id="Home">
    <el-row style="height: 100%">
      <el-col :offset="3" :span="8" style="height: 100%">
        <div style="height: 15%; display: flex; flex-direction: column; justify-content: center">
          <span style="color: white; font-size: x-large">AR Firework</span>
        </div>
        <div style="margin-top: 5%; height: 25%; display: flex; flex-direction: column; justify-content: center">
          <span style="color: white; font-size: xxx-large">AR 烟花</span>
          <span style="color: white; font-size: xxx-large">二维码生成器</span>
        </div>
        <div style="height: 7.5%; display: flex; flex-direction: column; justify-content: center">
          <span style="color: white; font-size: large">AR Fireworks QR Code Generator</span>
        </div>
        <div style="height: 7.5%; display: flex; flex-direction: column; justify-content: center">
          <span style="color: white; font-size: medium">定制专属纪念品，探索上海科技馆</span>
        </div>
        <div style="height: 30%; display: flex; flex-direction: column; justify-content: center">
          <el-button style="width: 160px"
                     @click="handleClickStart"
                     type="warning"
                     round>开始 / Explore</el-button>
        </div>
      </el-col>
      <el-col :offset="3" :span="4" style="height: 100%">
        <div style="height: 15%; display: flex; justify-content: flex-end; align-items: center; margin-right: 30px">
          <el-button type="text"
                     style="font-size: medium; margin-right: 20px"
                     @click="handleClickHistory"
                     class="TextButton">历史记录</el-button>
          <el-button v-if="$store.getters.getIsRoot"
                     type="text"
                     style="font-size: medium; margin-right: 20px"
                     @click="handleClickUserManage"
                     class="TextButton">用户管理</el-button>
        </div>
      </el-col>
      <el-col :span="3" style="height: 100%">
        <div style="height: 15%; display: flex; flex-direction: column; justify-content: center">
          <el-button v-if="$store.getters.getUsername === ''"
                     style="width: 180px"
                     @click="$router.push('/login')"
                     type="warning" round>登录 / 注册</el-button>
          <div v-else style="height: 100%; display: flex; justify-content: center; align-items: center">
            <el-dropdown @command="handleCommand">
            <span class="el-dropdown-link">
              <span>{{ $store.getters.getUsername.length > 10 ? $store.getters.getUsername.slice(0, 10) + '...' : $store.getters.getUsername }}</span>
              <i class="el-icon-arrow-down el-icon--right"></i>
            </span>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item command="logout">退出登录</el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  name: "Home",
  data() {
    return {

    }
  },
  methods: {
    async handleCommand(command) {
      if (command === 'logout') {
        if (!this.$store.getters.getHasCheckAuth) {
          await this.$checkAuth();
          if (!this.$store.getters.getHasCheckAuth) {
            this.$message.error('网络似乎出现了问题，请刷新后重试')
            return
          }
        }

        let {data} = await this.$axios.post(
            '/Logout'
        )

        if (data['status'] === 0) {
          this.$message.success('登出成功！')
          this.$store.commit("mutationsSetUsername", '')
        }
        else if (data['status'] === 2) {
          this.$message.error('登录过期，请刷新页面重试')
        }
      }
    },
    handleClickStart() {
      if(this.$store.getters.getUsername === '') {
        this.$message.error('请先登录！')
        this.$router.push('/login')
      }
      else {
        this.$router.push('/generator')
      }
    },
    handleClickHistory() {
      if (this.$store.getters.getUsername === '') {
        this.$message.error('请先登录！')
        this.$router.push('/login')
      }
      else {
        this.$router.push('/history')
      }
    },
    handleClickUserManage() {
      if (this.$store.getters.getUsername === '') {
        this.$message.error('未知错误，请刷新重试！')
      }
      else {
        this.$router.push('/user-manage')
      }
    }
  },
  mounted() {

  }
}
</script>

<style scoped>
#Home{
  height: 100%;
  background-image: url('~@/assets/Web-Home.png');
  background-position: center center;
  background-repeat: no-repeat;
  background-size: cover;
  background-attachment: fixed;
}

.TextButton {
  color: #FFC300;
  transition: color 0.25s;
}

.TextButton:hover {
  color: #fff0bf;
  transition: color 0.25s;
}

.el-dropdown-link {
  cursor: pointer;
  color: #FFC300;
  font-size: large;
}
.el-icon-arrow-down {
  font-size: large;
}
</style>