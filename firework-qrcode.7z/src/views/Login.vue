<template>
  <div id="Login">
    <el-row style="height: 100%">
      <el-col :offset="1" :span="1" style="height: 100%">
        <div style="height: 15%; display: flex; justify-content: center; align-items: center">
          <el-button type="warning"
                     @click="$router.push('/home')"
                     style="font-size: large"
                     icon="el-icon-arrow-left" circle></el-button>
        </div>
      </el-col>
      <el-col v-if="isLoginPage" :offset="12" :span="10" style="height: 100%; display: flex; flex-direction: column; justify-content: center">
        <div style="height: 10%; margin-bottom: 5%; display: flex; flex-direction: column; justify-content: center">
          <span style="color: white; font-size: xxx-large">登录 / Login</span>
        </div>
        <div style="height: 20%; display: flex; flex-direction: column; justify-content: center">
          <el-input style="width: 300px" prefix-icon="el-icon-user"
                    v-model="loginForm.username"
                    placeholder="用户名 / Username"></el-input>
          <el-input style="width: 300px; margin-top: 20px"
                    v-model="loginForm.password"
                    prefix-icon="el-icon-lock" placeholder="密码 / Password" show-password></el-input>
        </div>
        <div style="height: 10%; margin-bottom: 5%; display: flex; flex-direction: column; justify-content: center">
          <div>
            <el-button style="width: 135px"
                       @click="submitLoginForm"
                       type="warning" round>登录</el-button>
            <el-button style="width: 135px; margin-left: 30px"
                       @click="isLoginPage = false"
                       type="warning" plain round>注册</el-button>
          </div>
        </div>
      </el-col>
      <el-col v-else :offset="12" :span="10" style="height: 100%; display: flex; flex-direction: column; justify-content: center">
        <div style="height: 10%; margin-bottom: 5%; display: flex; flex-direction: column; justify-content: center">
          <span style="color: white; font-size: xxx-large">注册 / Register</span>
        </div>
        <div style="height: 35%; display: flex; flex-direction: column; justify-content: center">
          <el-input style="width: 300px" prefix-icon="el-icon-user"
                    v-model="registerForm.username"
                    placeholder="用户名 / Username"></el-input>
          <el-input style="width: 300px; margin-top: 20px"
                    v-model="registerForm.password"
                    prefix-icon="el-icon-lock" placeholder="密码 / Password" show-password></el-input>
          <el-input style="width: 300px; margin-top: 20px"
                    v-model="registerForm.confirmPassword"
                    prefix-icon="el-icon-lock" placeholder="确认密码 / Confirm Password" show-password></el-input>
          <el-input style="width: 300px; margin-top: 20px"
                    v-model="registerForm.message"
                    prefix-icon="el-icon-lock" placeholder="申请信息 / Submit Information"></el-input>
        </div>
        <div style="height: 10%; margin-bottom: 5%; display: flex; flex-direction: column; justify-content: center">
          <div>
            <el-button style="width: 135px"
                       @click="submitRegisterForm"
                       type="warning" round>注册</el-button>
            <el-button style="width: 135px; margin-left: 30px"
                       @click="isLoginPage = true"
                       type="warning" plain round>返回</el-button>
          </div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import {JSEncrypt} from "jsencrypt";

export default {
  name: "Login",
  data() {
    return {
      isLoginPage: true,
      loginForm: {
        username: '',
        password: ''
      },
      registerForm: {
        username: '',
        password: '',
        confirmPassword: '',
        message: ''
      }
    };
  },
  methods: {
    async submitRegisterForm() {
      let usernameLength = this.registerForm.username.length
      let passwordLength = this.registerForm.password.length
      let messageLength = this.registerForm.message.length

      if (usernameLength > 25) {
        this.$message.error('用户名的长度不能超过25个字符！')
        return
      }
      if (this.loginForm.username.includes(' ')) {
        this.$message.error('用户名不能包含空格！')
        return
      }
      if (passwordLength > 25 || passwordLength < 7) {
        this.$message.error('密码的长度不能超过25个字符或小于7个字符！')
        return
      }
      if (this.registerForm.password !== this.registerForm.confirmPassword) {
        this.$message.error('两次输入的密码不一致！')
        return
      }
      if (this.loginForm.password.includes(' ')) {
        this.$message.error('密码不能包含空格！')
        return
      }
      if (messageLength > 120) {
        this.$message.error('提交信息不能超过120个字符！')
      }

      if (!this.$store.getters.getHasCheckAuth) {
        await this.$checkAuth();
        if (!this.$store.getters.getHasCheckAuth) {
          this.$message.error('网络似乎出现了问题，请刷新后重试')
          return
        }
      }

      let jse = new JSEncrypt()
      jse.setPublicKey(this.$store.getters.getPublicKey)
      let {data} = await this.$axios.post(
          '/Register',
          {
            'username': this.registerForm.username,
            'password': jse.encrypt(this.registerForm.password),
            'message':this.registerForm.message
          }
      )

      if (data['status'] === 0) {
        this.$message.success('注册成功，请等待管理员审核')
        await this.$router.push('/home')
      }
      else if (data['status'] === 1) {
        this.$message.error('该用户名已被注册')
      }
      else if (data['status'] === 2) {
        this.$message.error('登录过期，请刷新页面重试')
      }
      else if (data['status'] === 3) {
        this.$message.error('密码中包含非法字符')
      }
    },

    async submitLoginForm() {

      let usernameLength = this.loginForm.username.length
      let passwordLength = this.loginForm.password.length

      if (usernameLength > 25) {
        this.$message.error('用户名的长度不能超过25个字符！')
        return
      }
      if (this.loginForm.username.includes(' ')) {
        this.$message.error('用户名不能包含空格！')
        return
      }
      if (passwordLength > 25 || passwordLength < 7) {
        this.$message.error('密码的长度不能超过25个字符或小于7个字符！')
        return
      }
      if (this.loginForm.password.includes(' ')) {
        this.$message.error('密码不能包含空格！')
        return
      }

      if (!this.$store.getters.getHasCheckAuth) {
        await this.$checkAuth();
        if (!this.$store.getters.getHasCheckAuth) {
          this.$message.error('网络似乎出现了问题，请刷新后重试')
          return
        }
      }

      let jse = new JSEncrypt()
      jse.setPublicKey(this.$store.getters.getPublicKey)
      let {data} = await this.$axios.post(
          '/Login',
          {
            'username': this.loginForm.username,
            'password': jse.encrypt(this.loginForm.password)
          }
      )

      if (data['status'] === 0) {
        this.$message.success('登录成功！')
        this.$store.commit('mutationsSetUsername', this.loginForm.username)
        this.$store.commit("mutationsSetIsRoot", data['value'])
        await this.$router.push('/home')
      }
      else if (data['status'] === 1) {
        this.$message.error('用户名或密码错误，或您的账号还未通过管理员的审核')
      }
      else if (data['status'] === 2) {
        this.$message.error('登录过期，请刷新页面重试')
      }
      else if (data['status'] === 3) {
        this.$message.error('密码中包含非法字符')
      }
    }
  }
}
</script>

<style scoped>
#Login {
  height: 100%;
  background-image: url('~@/assets/Web-Login.png');
  background-position: center center;
  background-repeat: no-repeat;
  background-size: cover;
  background-attachment: fixed;
}

#Login >>> .el-input__inner {
  border-radius: 20px;
}

</style>