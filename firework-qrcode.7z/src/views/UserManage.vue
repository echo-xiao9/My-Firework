<template>
  <div id="UserManage">
    <div id="UserManageMainBG">
      <el-scrollbar style="height: 100%">
        <div id="UserManageMain">
          <div id="UserManageTitle">
            <span style="color: #32325d; font-weight: bold; font-size: xx-large; ">用户管理</span>
          </div>
          <div id="UserManageTable">
            <el-table
                :data="tableData"
                border>
              <el-table-column
                  label="ID">
                <template slot-scope="scope">
                  <span>{{ scope.row.id }}</span>
                </template>
              </el-table-column>
              <el-table-column
                  label="用户名"
                  width="180">
                <template slot-scope="scope">
                  <el-popover
                      placement="top-start"
                      width="200"
                      trigger="hover"
                      :content="scope.row.username">
                    <span slot="reference">{{ scope.row.username.length > 10 ? scope.row.username.slice(0, 10) + '...' : scope.row.username }}</span>
                  </el-popover>
                </template>
              </el-table-column>
              <el-table-column
                  label="用户类型">
                <template slot-scope="scope">
                  <span>{{ scope.row['userType'] }}</span>
                </template>
              </el-table-column>
              <el-table-column
                  label="注册信息"
                  width="180">
                <template slot-scope="scope">
                  <el-popover
                      placement="top-start"
                      width="200"
                      trigger="hover"
                      :content="scope.row.message">
                    <span slot="reference">{{ scope.row.message.length > 10 ? scope.row.message.slice(0, 10) + '...' : scope.row.message }}</span>
                  </el-popover>
                </template>
              </el-table-column>
              <el-table-column label="操作" width="200">
                <template slot-scope="scope">
                  <el-button
                      v-if="scope.row['userType'] === '普通用户'"
                      size="mini"
                      type="danger"
                      :loading="isLoading"
                      @click="handleBlock(scope.$index, scope.row.id)">封禁用户</el-button>
                  <el-button
                      v-if="scope.row['userType'] === '封禁用户'"
                      size="mini"
                      type="success"
                      :loading="isLoading"
                      @click="handleUnBlock(scope.$index, scope.row.id)">解封用户</el-button>
                  <el-button
                      v-if="scope.row['userType'] === '待审核用户'"
                      size="mini"
                      type="success"
                      :loading="isLoading"
                      @click="handleEnable(scope.$index, scope.row.id)">授权</el-button>
                  <el-button
                      v-if="scope.row['userType'] === '待审核用户'"
                      size="mini"
                      type="danger"
                      :loading="isLoading"
                      @click="handleDelete(scope.$index, scope.row.id)">拒绝</el-button>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div style="margin-top: 20px; margin-bottom: 20px">
            <el-pagination
                :page-count="totalPage"
                :current-page.sync="currentPage"
                @current-change="handleGet"
                layout="prev, pager, next">
            </el-pagination>
          </div>
        </div>
      </el-scrollbar>
    </div>
    <div id="HomeButton">
      <el-button style="box-shadow: 1px 1px 5px 0 rgba(0, 0, 0, 0.3); font-size: x-large; width: 50px; height: 50px"
                 @click="$router.push('/home')"
                 icon="el-icon-s-home" type="warning" circle></el-button>
    </div>
  </div>
</template>

<script>
const MANAGER = "管理员"
const NORMAL = "普通用户"
const FORBIDDEN = "封禁用户"
const PENDING = "待审核用户"

export default {
  name: "UserManage",
  data() {
    return {
      tableData: [],
      totalPage: 1,
      currentPage: 1,
      isLoading: false,
    }
  },
  methods: {
    async handleGet(currentPage) {
      if (!this.$store.getters.getHasCheckAuth) {
        await this.$checkAuth();
        if (!this.$store.getters.getHasCheckAuth) {
          this.$message.error('网络似乎出现了问题，请刷新后重试')
          return
        }
      }

      let {data} = await this.$axios.post(
          '/GetUserList',
          {
            'pageInd': currentPage,
            'pageSize': 8
          }
      )

      if (data['status'] === 0) {
        this.tableData = data['value']['userList']
        this.totalPage = data['value']['pageNumber']
        for (let it of this.tableData) {
          if (it['userType'] === "MANAGER") {
            it['userType'] = MANAGER
          }
          else if (it['userType'] === "NORMAL") {
            it['userType'] = NORMAL
          }
          else if (it['userType'] === "FORBIDDEN") {
            it['userType'] = FORBIDDEN
          }
          else if (it['userType'] === "PENDING") {
            it['userType'] = PENDING
          }
        }
      }
      else if (data['status'] === 1) {
        this.$message.error('获取列表失败，请刷新重试')
      }
      else if (data['status'] === 2) {
        this.$message.error('登录过期，请刷新页面重试')
      }
    },
    async handleDelete(index, id) {
      this.isLoading = true

      let {data} = await this.$axios.post(
          '/DeleteUser',
          {
            'userId': id
          }
      )

      if (data['status'] === 0) {
        this.$message.success('拒绝申请成功！')
        await this.handleGet(this.tableData.length === 1 ? this.currentPage - 1 : this.currentPage)
      }
      else if (data['status'] === 1) {
        this.$message.error('操作失败，请刷新页面重试')
      }
      else if (data['status'] === 2) {
        this.$message.error('登录过期，请刷新页面重试')
      }

      this.isLoading = false
    },
    async handleEnable(index, id) {
      this.isLoading = true

      let {data} = await this.$axios.post(
          '/AuthUser',
          {
            'userId': id
          }
      )

      if (data['status'] === 0) {
        this.$message.success('授权成功！')
        this.tableData[index]['userType'] = NORMAL
      }
      else if (data['status'] === 1) {
        this.$message.error('操作失败，请刷新页面重试')
      }
      else if (data['status'] === 2) {
        this.$message.error('登录过期，请刷新页面重试')
      }

      this.isLoading = false
    },
    async handleBlock(index, id) {
      this.isLoading = true

      let {data} = await this.$axios.post(
          '/BlockUser',
          {
            'userId': id
          }
      )

      if (data['status'] === 0) {
        this.$message.success('封禁成功！')
        this.tableData[index]['userType'] = FORBIDDEN
      }
      else if (data['status'] === 1) {
        this.$message.error('操作失败，请刷新页面重试')
      }
      else if (data['status'] === 2) {
        this.$message.error('登录过期，请刷新页面重试')
      }

      this.isLoading = false
    },
    async handleUnBlock(index, id) {
      this.isLoading = true

      let {data} = await this.$axios.post(
          '/UnBlockUser',
          {
            'userId': id
          }
      )

      if (data['status'] === 0) {
        this.$message.success('解封成功！')
        this.tableData[index]['userType'] = NORMAL
      }
      else if (data['status'] === 1) {
        this.$message.error('操作失败，请刷新页面重试')
      }
      else if (data['status'] === 2) {
        this.$message.error('登录过期，请刷新页面重试')
      }

      this.isLoading = false
    }
  },
  created() {
    this.handleGet(1)
  }
}
</script>

<style scoped>
#UserManage {
  height: 100%;
  background-image: url('~@/assets/Web-Home.png');
  background-position: center center;
  background-repeat: no-repeat;
  background-size: cover;
  background-attachment: fixed;
  display: flex;
  justify-content: center;
  align-items: center;
}

#UserManage >>> .el-scrollbar__wrap{
  overflow-x: hidden;
}

#UserManageMainBG {
  height: 95%;
  width: 65%;
  border-radius: 5px;
  background-color: white;
}

#UserManageMain {
  height: 100%;
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
}

#UserManageTitle {
  margin: 40px 0 20px;
}

#UserManageTable {
  width: 80%;
}

#HomeButton {
  position: absolute;
  right: 100px;
  bottom: 50px;
  height: 80px;
  width: 80px;
}
</style>