<template>
  <div id="History">
    <div id="HistoryMainBG">
      <el-scrollbar style="height: 100%">
        <div id="HistoryMain">
          <div id="HistoryTitle">
            <span style="color: #32325d; font-weight: bold; font-size: xx-large; ">历史记录</span>
          </div>
          <div id="HistoryTable">
            <el-table
                :data="tableData"
                border>
              <el-table-column
                  label="ID">
                <template slot-scope="scope">
                  <span>{{ scope.row.id }}</span>
                </template>
              </el-table-column>
              <el-table-column
                  label="创建者"
                  v-if="$store.getters.getIsRoot">
                <template slot-scope="scope">
                  <span>{{scope.row.username}}</span>
                </template>
              </el-table-column>
              <el-table-column
                  width="180"
                  label="日期">
                <template slot-scope="scope">
                  <span>{{ new Date(scope.row.date).toLocaleString() }}</span>
                </template>
              </el-table-column>
              <el-table-column
                  label="二维码数量">
                <template slot-scope="scope">
                  <span>{{ scope.row.number }}</span>
                </template>
              </el-table-column>
              <el-table-column label="操作" width="220">
                <template slot-scope="scope">
                  <el-button
                      size="mini"
                      :loading="isLoading"
                      @click="handleDownload(scope.row.id)">重新下载</el-button>
                  <el-button
                      size="mini"
                      type="danger"
                      :loading="isLoading"
                      @click="handleDelete(scope.$index, scope.row.id)">删除</el-button>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div style="margin-top: 20px; margin-bottom: 20px">
            <el-pagination
                :page-count="totalPage"
                :current-page.sync="currentPage"
                @current-change="handleGet"
                layout="prev, pager, next">
            </el-pagination>
          </div>
        </div>
      </el-scrollbar>
    </div>
    <div id="HomeButton">
      <el-button style="box-shadow: 1px 1px 5px 0 rgba(0, 0, 0, 0.3); font-size: x-large; width: 50px; height: 50px"
                 @click="$router.push('/home')"
                 icon="el-icon-s-home" type="warning" circle></el-button>
    </div>
  </div>
</template>

<script>
export default {
  name: "History",
  data() {
    return {
      tableData: [],
      totalPage: 1,
      currentPage: 1,
      isLoading: false,
    }
  },
  methods: {
    async handleGet(currentPage) {
      if (!this.$store.getters.getHasCheckAuth) {
        await this.$checkAuth();
        if (!this.$store.getters.getHasCheckAuth) {
          this.$message.error('网络似乎出现了问题，请刷新后重试')
          return
        }
      }

      let {data} = await this.$axios.post(
          '/GetTagOrders',
          {
            'pageInd': currentPage,
            'pageSize': 8
          }
      )

      if (data['status'] === 0) {
        this.tableData = data['value']['tagOrders']
        this.totalPage = data['value']['pageNumber']
      }
      else if (data['status'] === 2) {
        this.$message.error('登录过期，请刷新页面重试')
      }
    },
    async handleDownload(id) {
      this.isLoading = true

      await this.$axios.post(
          '/GetZipImages',
          {
            'tagOrderId': id
          },
          {
            responseType: 'blob',
            withCredentials: true,
          }
      ).then(res => {
        let data = res['data'];
        let fileReader = new FileReader();
        fileReader.onload = function () {
          const blob = new Blob([res['data']], {type: 'application/zip'});
          const filename = res.headers['content-disposition'];
          const downloadElement = document.createElement('a');
          const href = window.URL.createObjectURL(blob);
          downloadElement.href = href;
          downloadElement.download = filename.split('=')[1];
          document.body.appendChild(downloadElement);
          downloadElement.click();
          document.body.removeChild(downloadElement);
          window.URL.revokeObjectURL(href)
        };
        fileReader.readAsText(data)
      })

      this.isLoading = false
    },
    async handleDelete(index, id) {
      this.isLoading = true

      let {data} = await this.$axios.post(
          '/DeleteTagOrder',
          {
            'tagOrderId': id
          }
      )

      if (data['status'] === 0) {
        this.$message.success('删除成功！')
        if (this.totalPage === 1 && this.tableData.length === 1){
          this.tableData = []
        }
        else if (this.tableData.length === 1) {
          await this.handleGet(this.currentPage - 1)
        }
        else {
          await this.handleGet(this.currentPage)
        }
      }
      else if (data['status'] === 2) {
        this.$message.error('登录过期，请刷新页面重试')
      }

      this.isLoading = false
    }
  },
  created() {
    this.handleGet(1)
  }
}
</script>

<style scoped>
#History {
  height: 100%;
  background-image: url('~@/assets/Web-Home.png');
  background-position: center center;
  background-repeat: no-repeat;
  background-size: cover;
  background-attachment: fixed;
  display: flex;
  justify-content: center;
  align-items: center;
}

#History >>> .el-scrollbar__wrap{
  overflow-x: hidden;
}

#HistoryMainBG {
  height: 95%;
  width: 65%;
  border-radius: 5px;
  background-color: white;
}

#HistoryMain {
  height: 100%;
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
}

#HistoryTitle {
  margin: 40px 0 20px;
}

#HistoryTable {
  width: 80%;
}

#HomeButton {
  position: absolute;
  right: 100px;
  bottom: 50px;
  height: 80px;
  width: 80px;
}
</style>