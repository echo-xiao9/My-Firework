<template>
  <div id="Generator">
    <el-row style="height: 100%">
      <el-col :offset="3" :span="9" style="height: 100%">
        <div style="margin-top: 15%; height: 5%; display: flex; flex-direction: column; justify-content: center">
          <span>Generate QR Code</span>
        </div>
        <div style="height: 15%; display: flex; flex-direction: column; justify-content: center">
          <span style="font-size: xxx-large;">生成二维码</span>
        </div>
        <div style="margin-top: 6%; height: 7%; display: flex; align-items: center;">
          <span style="font-size: x-large; font-weight: bold">生成数量：</span>
          <el-input-number style="width: 80px" size="small" :min="1" :max="100" v-model="input" :controls="false"></el-input-number>
        </div>
        <div style="height: 2%; width: 200px; background-color: #C86DD7">

        </div>
        <div style="height: 40%; display: flex; flex-direction: column; justify-content: center">
          <el-button type="primary"
                     style="width: 200px; margin-bottom: 20px;"
                     @click="GenerateTag"
                     :loading="isGenerating"
                     round>立即生成</el-button>
          <el-button type="primary" :disabled="orderId === 0"
                     style="width: 200px; margin-left: 0; margin-bottom: 20px"
                     @click="DownloadQrCodes"
                     :loading="isDownloading"
                     round>重新下载</el-button>
          <el-button type="primary"
                     style="width: 200px; margin-left: 0"
                     @click="$router.push('/home')"
                     round>返回主界面</el-button>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  name: "Generator",
  data() {
    return {
      input: 0,
      orderId: 0,
      isGenerating: false,
      isDownloading: false,
    }
  },
  methods: {
    async GenerateTag() {
      this.isGenerating = true
      if (!this.$store.getters.getHasCheckAuth) {
        await this.$checkAuth();
        if (!this.$store.getters.getHasCheckAuth) {
          this.$message.error('网络似乎出现了问题，请刷新后重试')

          this.isGenerating = false
          return
        }
      }

      let {data} = await this.$axios.post(
          '/GenerateRandomTags',
          {
            'number': this.input
          }
      )
      if (data['status'] === 0) {
        this.$message.success('生成成功！正在传输文件中……')
        this.orderId = data['value']
        await this.DownloadQrCodes()
      }
      else {
        this.$message.error('生成失败！请刷新试试！')
      }

      this.isGenerating = false
    },
    async DownloadQrCodes() {
      this.isDownloading = true

      await this.$axios.post(
          '/GetZipImages',
          {
            'tagOrderId': this.orderId
          },
          {
            responseType: 'blob',
            withCredentials: true,
          }
      ).then(res => {
        let data = res['data'];
        let fileReader = new FileReader();
        fileReader.onload = function () {
          const blob = new Blob([res['data']], {type: 'application/zip'});
          const filename = res.headers['content-disposition'];
          const downloadElement = document.createElement('a');
          const href = window.URL.createObjectURL(blob);
          downloadElement.href = href;
          downloadElement.download = filename.split('=')[1];
          document.body.appendChild(downloadElement);
          downloadElement.click();
          document.body.removeChild(downloadElement);
          window.URL.revokeObjectURL(href)
        };
        fileReader.readAsText(data)
      })

      this.isDownloading = false
    }
  }
}
</script>

<style scoped>
#Generator {
  height: 100%;
  background-image: url('~@/assets/Web-Generate.png');
  background-position: center center;
  background-repeat: no-repeat;
  background-size: cover;
  background-attachment: fixed;
}

</style>