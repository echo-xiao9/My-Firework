import VueRouter from "vue-router";
import Login from "@/views/Login";
import Home from "@/views/Home";
import Generator from "@/views/Generator";
import History from "@/views/History";
import UserManage from "@/views/UserManage";
import store from "@/store/index"

const routes = [
    {
        path: '/login', component: Login
    },
    {
        path: '/home', component: Home
    },
    {
        path: '/generator', component: Generator
    },
    {
        path: '/history', component: History
    },
    {
        path: '/user-manage', component: UserManage
    },
    {
        path: '/',
        redirect: '/home'
    }
]

const router = new VueRouter({
    name: 'router',
    routes,
    mode: 'history',
    base: '/firework-generator/'
})

router.beforeEach((to, from, next) => {
    if (to.path !== '/home' && to.path !== '/login' && store.getters.getUsername === '') {
        next('/home')
    }
    else if (to.path === '/login' && store.getters.getUsername !== '') {
        next('/home')
    }
    else if (to.path === '/user-manage' && !store.getters.getIsRoot) {
        next('/home')
    }
    else {
        next()
    }
})

export default router