package com.fireworklab.backend.serviceImpl;

import com.fireworklab.backend.entity.*;
import com.fireworklab.backend.repository.QrCodeUserRepository;
import com.fireworklab.backend.repository.TagOrderRepository;
import com.fireworklab.backend.repository.TagRepository;
import com.google.zxing.common.BitMatrix;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.*;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;


class QrCodeServiceImplTest {

    @InjectMocks
    private QrCodeServiceImpl qrCodeService;

    @Mock
    private QrCodeUserRepository qrCodeUserRepository;

    @Mock
    private TagOrderRepository tagOrderRepository;

    @Mock
    private TagRepository tagRepository;

    final String Empty = "";

    final Integer RootId = 1;
    final String RootUsername = "root";
    final String RootPassword = "root-password"
            ;
    final String NewUsername = "TEST_USERNAME";
    final String NewPassword = "1234567";

    final Integer PendingId = 3;
    final String PendingUsername = "PENDING_USERNAME";
    final String PendingPassword = "123456";

    final Integer NormalId = 4;
    final String NormalUsername = "NORMAL_USERNAME";
    final String NormalPassword = "12345678";

    final Integer ForbiddenId = 5;
    final String ForbiddenUsername = "FORBIDDEN_USERNAME";
    final String ForbiddenPassword = "1234567890";

    final Integer NewTagOrderId = 123;

    final Integer ExistTagOrderId = 12;
    final Integer ExistTagOrderWithListId = 13;

    final Integer TestPageInd = 1;
    final Integer TestPageSize = 10;

    final Long ExistTag = 19260817L;
    final Long UnExistTag = 123L;

    @BeforeEach
    public void setUp() {
        UserMessage msg = new UserMessage();
        msg.setMessage("");

        QrCodeUser rootUser = new QrCodeUser();
        rootUser.setId(RootId);
        rootUser.setUsername(RootUsername);
        rootUser.setPassword(RootPassword);
        rootUser.setUserType(QrCodeUserType.MANAGER);
        rootUser.setUserMessage(msg);

        QrCodeUser pendingUser = new QrCodeUser();
        pendingUser.setId(PendingId);
        pendingUser.setUsername(PendingUsername);
        pendingUser.setPassword(PendingPassword);
        pendingUser.setUserType(QrCodeUserType.PENDING);
        pendingUser.setUserMessage(msg);

        QrCodeUser normalUser = new QrCodeUser();
        normalUser.setId(NormalId);
        normalUser.setUsername(NormalUsername);
        normalUser.setPassword(NormalPassword);
        normalUser.setUserType(QrCodeUserType.NORMAL);
        normalUser.setUserMessage(msg);

        QrCodeUser forbiddenUser = new QrCodeUser();
        forbiddenUser.setId(ForbiddenId);
        forbiddenUser.setUsername(ForbiddenUsername);
        forbiddenUser.setPassword(ForbiddenPassword);
        forbiddenUser.setUserType(QrCodeUserType.FORBIDDEN);
        forbiddenUser.setUserMessage(msg);

        TagOrder newTagOrder = new TagOrder();
        newTagOrder.setId(NewTagOrderId);

        TagOrder existTagOrder = new TagOrder();
        existTagOrder.setId(ExistTagOrderId);
        existTagOrder.setQrCodeUser(rootUser);

        TagOrder existTagOrderWithList = new TagOrder();
        existTagOrderWithList.setId(ExistTagOrderWithListId);
        existTagOrderWithList.setQrCodeUser(rootUser);
        existTagOrderWithList.setTagList(new ArrayList<>());
        Tag tag = new Tag();
        tag.setId(19260817L);
        existTagOrderWithList.getTagList().add(tag);
        existTagOrderWithList.setDate(new Date());

        List<TagOrder> tmpTagOrderList = new ArrayList<>();
        tmpTagOrderList.add(existTagOrderWithList);
        Page<TagOrder> tagOrderPage = new PageImpl<>(tmpTagOrderList);

        List<QrCodeUser> qrCodeUserList = new ArrayList<>();
        qrCodeUserList.add(rootUser);
        Page<QrCodeUser> qrCodeUserPage = new PageImpl<>(qrCodeUserList);


        MockitoAnnotations.openMocks(this);
        Mockito.when(qrCodeUserRepository.existsByUsername(Empty)).thenReturn(false);
        Mockito.when(qrCodeUserRepository.existsByUsername(RootUsername)).thenReturn(true);

        Mockito.when(qrCodeUserRepository.getByUsername(NewUsername)).thenReturn(null);
        Mockito.when(qrCodeUserRepository.getByUsername(RootUsername)).thenReturn(rootUser);
        Mockito.when(qrCodeUserRepository.getByUsername(PendingUsername)).thenReturn(pendingUser);
        Mockito.when(qrCodeUserRepository.getByUsername(NormalUsername)).thenReturn(normalUser);
        Mockito.when(qrCodeUserRepository.getById(RootId)).thenReturn(rootUser);
        Mockito.when(qrCodeUserRepository.getById(PendingId)).thenReturn(pendingUser);
        Mockito.when(qrCodeUserRepository.getById(NormalId)).thenReturn(normalUser);
        Mockito.when(qrCodeUserRepository.getById(ForbiddenId)).thenReturn(forbiddenUser);

        Mockito.when(qrCodeUserRepository.findAll(Mockito.any(Pageable.class))).thenReturn(qrCodeUserPage);

        Mockito.when(tagOrderRepository.save(Mockito.any(TagOrder.class))).thenReturn(null).thenReturn(newTagOrder);

        Mockito.when(tagOrderRepository.getById(NewTagOrderId)).thenReturn(null);
        Mockito.when(tagOrderRepository.getById(ExistTagOrderId)).thenReturn(existTagOrder);
        Mockito.when(tagOrderRepository.getById(ExistTagOrderWithListId)).thenReturn(existTagOrderWithList);

        Mockito.when(tagOrderRepository.findAll(PageRequest.of(TestPageInd, TestPageSize))).thenReturn(tagOrderPage);
        Mockito.when(tagOrderRepository.findAllByQrCodeUser(Mockito.any(QrCodeUser.class), Mockito.any(Pageable.class))).thenReturn(tagOrderPage);

        Mockito.when(tagRepository.existsById(ExistTag)).thenReturn(true);
        Mockito.when(tagRepository.existsById(UnExistTag)).thenReturn(false);
    }

    @Test
    void register() {
        assertFalse(qrCodeService.Register(Empty, Empty, Empty));

        assertFalse(qrCodeService.Register(RootUsername, RootPassword, Empty));

        assertTrue(qrCodeService.Register(NewUsername, NewPassword, Empty));
    }

    @Test
    void login() {
        assertFalse(qrCodeService.Login(NewUsername, NewPassword));

        assertFalse(qrCodeService.Login(PendingUsername, PendingPassword));

        assertTrue(qrCodeService.Login(RootUsername, RootPassword));
    }

    @Test
    void checkRoot() {
        assertFalse(qrCodeService.CheckRoot(NewUsername));

        assertTrue(qrCodeService.CheckRoot(RootUsername));
    }

    @Test
    void generateRandomTags() {
        assertEquals(0, qrCodeService.GenerateRandomTags(NewUsername, 10));

        assertEquals(NewTagOrderId, qrCodeService.GenerateRandomTags(RootUsername, 10));

    }

    @Test
    void getImageMatrix() {

        List<BitMatrix> bitMatrices = qrCodeService.GetImageMatrix(NewUsername, NewTagOrderId);
        assertNull(bitMatrices);

        bitMatrices = qrCodeService.GetImageMatrix(NewUsername, ExistTagOrderId);
        assertNull(bitMatrices);

        bitMatrices = qrCodeService.GetImageMatrix(RootUsername, ExistTagOrderId);
        assertNull(bitMatrices);

        bitMatrices = qrCodeService.GetImageMatrix(RootUsername, ExistTagOrderWithListId);
        assertEquals(bitMatrices.size(), 1);
    }

    @Test
    void getTagOrders() {

        assertNull(qrCodeService.GetTagOrders(NewUsername, TestPageInd, TestPageSize));
        assertNotNull(qrCodeService.GetTagOrders(RootUsername, TestPageInd, TestPageSize));
        assertNull(qrCodeService.GetTagOrders(PendingUsername, TestPageInd, TestPageSize));
        assertNotNull(qrCodeService.GetTagOrders(NormalUsername, TestPageInd, TestPageSize));
    }

    @Test
    void deleteTagOrders() {

        assertFalse(qrCodeService.DeleteTagOrders(NewUsername, NewTagOrderId));
        assertFalse(qrCodeService.DeleteTagOrders(NormalUsername, ExistTagOrderWithListId));
        assertTrue(qrCodeService.DeleteTagOrders(RootUsername, ExistTagOrderWithListId));
    }

    @Test
    void checkTag() {

        assertTrue(qrCodeService.CheckTag(ExistTag));
        assertFalse(qrCodeService.CheckTag(UnExistTag));
    }

    @Test
    void getUserList() {

        assertNull(qrCodeService.GetUserList(NewUsername, TestPageInd, TestPageSize));
        assertNull(qrCodeService.GetUserList(NormalUsername, TestPageInd, TestPageSize));
        assertNotNull(qrCodeService.GetUserList(RootUsername, TestPageInd, TestPageSize));
    }

    @Test
    void deleteUsers() {

        assertFalse(qrCodeService.DeleteUsers(NewUsername, RootId));
        assertFalse(qrCodeService.DeleteUsers(NormalUsername, RootId));
        assertFalse(qrCodeService.DeleteUsers(RootUsername, RootId));
        assertTrue(qrCodeService.DeleteUsers(RootUsername, PendingId));
    }

    @Test
    void authUsers() {

        assertFalse(qrCodeService.AuthUsers(NewUsername, RootId));
        assertFalse(qrCodeService.AuthUsers(NormalUsername, RootId));
        assertFalse(qrCodeService.AuthUsers(RootUsername, RootId));
        assertTrue(qrCodeService.AuthUsers(RootUsername, PendingId));
    }

    @Test
    void blockUsers() {

        assertFalse(qrCodeService.BlockUsers(NewUsername, RootId));
        assertFalse(qrCodeService.BlockUsers(NormalUsername, RootId));
        assertFalse(qrCodeService.BlockUsers(RootUsername, RootId));
        assertTrue(qrCodeService.BlockUsers(RootUsername, NormalId));
    }

    @Test
    void unBlockUsers() {

        assertFalse(qrCodeService.UnBlockUsers(NewUsername, RootId));
        assertFalse(qrCodeService.UnBlockUsers(NormalUsername, RootId));
        assertFalse(qrCodeService.UnBlockUsers(RootUsername, RootId));
        assertTrue(qrCodeService.UnBlockUsers(RootUsername, ForbiddenId));
    }
}