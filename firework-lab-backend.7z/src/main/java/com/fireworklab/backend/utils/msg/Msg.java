package com.fireworklab.backend.utils.msg;

import lombok.Getter;

@Getter
public class Msg {

    private final Integer status;
    private final Object value;

    public Msg(Integer status) {
        this.status = status;
        this.value = "";
    }

    public Msg(Integer status, Object value) {
        this.status = status;
        this.value = value;
    }
}
