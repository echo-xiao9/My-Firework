package com.fireworklab.backend.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@DiscriminatorValue(value = "Image")
public class FireworkImage extends FireworkBase{

    @Column(name = "float_1")
    private Double initialVelocity;

    @Column(name = "float_2")
    private Integer width;

    @Column(name = "float_3")
    private Integer height;

    @Column(name = "str_1")
    @Enumerated(value = EnumType.STRING)
    private DefaultImageType defaultImage;

    @OneToOne(mappedBy = "fireworkImage", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private RawImage rawImage;
}
