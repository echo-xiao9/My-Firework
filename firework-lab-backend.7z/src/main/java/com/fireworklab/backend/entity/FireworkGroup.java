package com.fireworklab.backend.entity;

import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Entity
@Data
@Table(name = "firework_group")
public class FireworkGroup {

    @Id
    @Column(name = "tag")
    private Long tag;

    @Column(name = "model")
    @Enumerated(value = EnumType.STRING)
    private ModelType model;

    @OneToOne(mappedBy = "fireworkGroup", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
    private RawAudio rawAudio;

    @OneToMany(mappedBy = "fireworkGroup", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
    private List<FireworkBase> fireworkList;
}
