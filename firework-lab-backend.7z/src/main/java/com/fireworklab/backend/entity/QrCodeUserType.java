package com.fireworklab.backend.entity;

public enum QrCodeUserType {
    MANAGER, NORMAL, PENDING, FORBIDDEN
}
