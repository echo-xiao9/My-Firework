package com.fireworklab.backend.entity;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Data
@Table(name = "tag_order")
public class TagOrder {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    Integer id;

    @Column(name = "date")
    Date date;

    @OneToMany(mappedBy = "tagOrder", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    List<Tag> tagList;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    QrCodeUser qrCodeUser;
}
