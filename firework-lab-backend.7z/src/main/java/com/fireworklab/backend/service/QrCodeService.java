package com.fireworklab.backend.service;

import com.fireworklab.backend.dto.TagOrderListDto;
import com.fireworklab.backend.dto.UserListDto;
import com.google.zxing.common.BitMatrix;

import java.util.List;

public interface QrCodeService {

    boolean Register (String username, String password, String message);

    boolean Login (String username, String password);

    boolean CheckRoot (String username);

    Integer GenerateRandomTags (String username, Integer number);

    List<BitMatrix> GetImageMatrix (String username, Integer tagOrderId);

    TagOrderListDto GetTagOrders (String username, Integer pageInd, Integer pageSize);

    boolean DeleteTagOrders (String username, Integer tagOrderId);

    boolean CheckTag (Long tag);

    UserListDto GetUserList (String username, Integer pageInd, Integer pageSize);

    boolean DeleteUsers (String username, Integer userId);

    boolean AuthUsers (String username, Integer userId);

    boolean BlockUsers (String username, Integer userId);

    boolean UnBlockUsers (String username, Integer userId);
}
