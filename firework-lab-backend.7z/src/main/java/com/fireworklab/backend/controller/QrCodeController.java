package com.fireworklab.backend.controller;

import com.alibaba.fastjson.JSONObject;
import com.fireworklab.backend.dto.TagOrderListDto;
import com.fireworklab.backend.dto.UserListDto;
import com.fireworklab.backend.repository.FireworkGroupRepository;
import com.fireworklab.backend.service.QrCodeService;
import com.fireworklab.backend.utils.msg.Msg;
import com.fireworklab.backend.utils.session.SessionUtil;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import javax.crypto.Cipher;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@CrossOrigin(origins = "http://116.63.36.119:8080", allowCredentials = "true")
@RestController
public class QrCodeController {

    private static final int maxTagNumber = 100;

    private QrCodeService qrCodeService;

    private FireworkGroupRepository fireworkGroupRepository;

    @Autowired
    public void setQrCodeService(QrCodeService qrCodeService) {
        this.qrCodeService = qrCodeService;
    }

    @Autowired
    public void setFireworkGroupRepository(FireworkGroupRepository fireworkGroupRepository) {
        this.fireworkGroupRepository = fireworkGroupRepository;
    }

    private String GetPassword(byte[] rawPassword, PrivateKey privateKey) throws Exception {

        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.DECRYPT_MODE, privateKey);
        return new String(cipher.doFinal(rawPassword), StandardCharsets.UTF_8);
    }

    @PostMapping("/CheckSession")
    public Msg CheckSession() throws NoSuchAlgorithmException {

        JSONObject json = SessionUtil.getAuth();
        if (json == null) {
            KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
            keyPairGenerator.initialize(1024);
            KeyPair keyPair = keyPairGenerator.generateKeyPair();

            json = new JSONObject();
            json.put(SessionUtil.USERNAME, "");
            json.put(SessionUtil.PRIVATE_TOKEN, keyPair.getPrivate());
            json.put(SessionUtil.PUBLIC_TOKEN, keyPair.getPublic());
            SessionUtil.setSession(json);

            return new Msg(1, Base64.encodeBase64String(keyPair.getPublic().getEncoded()));
        }
        else if (json.getString(SessionUtil.USERNAME).equals("")) {

            return new Msg(1, json.getObject(SessionUtil.PUBLIC_TOKEN, PublicKey.class).getEncoded());
        }

        JSONObject res = new JSONObject();
        String username = json.getString(SessionUtil.USERNAME);
        res.put("username", username);
        res.put("isRoot", qrCodeService.CheckRoot(username));

        return new Msg(0, res);
    }

    @PostMapping("/Register")
    public Msg Register(@RequestBody JSONObject json) {

        JSONObject sessionJson = SessionUtil.getAuth();
        if (sessionJson == null) {
            return new Msg(2);
        }

        String username = json.getString("username");
        String message = json.getString("message");
        String rawPassword = json.getString("password");

        String password;
        try {
            password = GetPassword(Base64.decodeBase64(rawPassword), sessionJson.getObject(SessionUtil.PRIVATE_TOKEN, PrivateKey.class));

        } catch (Exception e) {
            return new Msg(3);
        }

        if (username.length() < 4 || username.length() > 25 || password.length() < 7 || password.length() > 25 || message.length() > 120) {
            return new Msg(1);
        }

        if (qrCodeService.Register(username, password, message)) {

            return new Msg(0);
        }
        return new Msg(1);
    }

    @PostMapping("/Login")
    public Msg Login(@RequestBody JSONObject json) {

        JSONObject sessionJson = SessionUtil.getAuth();
        if (sessionJson == null) {
            return new Msg(2);
        }
        if (!sessionJson.getString(SessionUtil.USERNAME).equals("")) {
            return new Msg(0,  qrCodeService.CheckRoot(sessionJson.getString(SessionUtil.USERNAME)));
        }

        String username = json.getString("username");
        String rawPassword = json.getString("password");

        String password;
        try {
            password = GetPassword(Base64.decodeBase64(rawPassword), sessionJson.getObject(SessionUtil.PRIVATE_TOKEN, PrivateKey.class));

        } catch (Exception e) {
            return new Msg(3);
        }

        if (username.length() < 4 || username.length() > 25 || password.length() < 7 || password.length() > 25) {
            return new Msg(1);
        }

        if (qrCodeService.Login(username, password)) {

            sessionJson.put(SessionUtil.USERNAME, username);
            SessionUtil.setSession(sessionJson);
            return new Msg(0, qrCodeService.CheckRoot(username));
        }
        return new Msg(1);
    }

    @PostMapping("/Logout")
    public Msg Logout() {

        JSONObject sessionJson = SessionUtil.getAuth();
        if (sessionJson == null) {
            return new Msg(2);
        }
        sessionJson.put(SessionUtil.USERNAME, "");
        SessionUtil.setSession(sessionJson);

        return new Msg(0);
    }

    @PostMapping("/GenerateRandomTags")
    public Msg GenerateRandomTags(@RequestBody JSONObject json) {

        JSONObject sessionJson = SessionUtil.getAuth();
        if (sessionJson == null || sessionJson.getString(SessionUtil.USERNAME).equals("")) {
            return new Msg(2);
        }

        String username = sessionJson.getString(SessionUtil.USERNAME);
        Integer requestNumber = json.getInteger("number");

        if (requestNumber <= maxTagNumber
                && requestNumber > 0) {

            Integer orderId = qrCodeService.GenerateRandomTags(username, requestNumber);
            if (orderId != 0) {

                return new Msg(0, orderId);
            }

        }

        return new Msg(1);
    }

    @PostMapping(value = "/GetZipImages", produces = "application/zip")
    public ResponseEntity<StreamingResponseBody> GetZipImages(@RequestBody JSONObject json) {

        JSONObject sessionJson = SessionUtil.getAuth();
        if (sessionJson == null || sessionJson.getString(SessionUtil.USERNAME).equals("")) {
            return ResponseEntity.noContent().build();
        }

        String username = sessionJson.getString(SessionUtil.USERNAME);

        Integer tagOrderId = json.getInteger("tagOrderId");

        List<BitMatrix> bitMatrixList = qrCodeService.GetImageMatrix(username, tagOrderId);

        return ResponseEntity
                .ok()
                .header("Content-Disposition", "attachment; filename=" + tagOrderId.toString() + ".zip")
                .header("Access-Control-Expose-Headers", "Content-Disposition")
                .body(outputStream -> {

                    ZipOutputStream zipOutputStream = new ZipOutputStream(outputStream);

                    if (bitMatrixList != null) {

                        int i = 1;
                        for (BitMatrix bitMatrix : bitMatrixList) {

                            zipOutputStream.putNextEntry(new ZipEntry(i + ".png"));
                            ++i;
                            MatrixToImageWriter.writeToStream(bitMatrix, "PNG", zipOutputStream);
                            zipOutputStream.closeEntry();
                        }

                        zipOutputStream.close();
                    }
                });
    }

    @PostMapping("/GetTagOrders")
    public Msg GetTagOrders(@RequestBody JSONObject json) {

        JSONObject sessionJson = SessionUtil.getAuth();
        if (sessionJson == null || sessionJson.getString(SessionUtil.USERNAME).equals("")) {
            return new Msg(2);
        }

        String username = sessionJson.getString(SessionUtil.USERNAME);
        Integer pageInd = json.getInteger("pageInd") - 1;
        Integer pageSize = json.getInteger("pageSize");

        TagOrderListDto tagOrders = qrCodeService.GetTagOrders(username, pageInd, pageSize);
        if (tagOrders != null) {

            return new Msg(0, tagOrders);
        }
        return new Msg(1);
    }

    @PostMapping("/DeleteTagOrder")
    public Msg DeleteTagOrders(@RequestBody JSONObject json) {

        JSONObject sessionJson = SessionUtil.getAuth();
        if (sessionJson == null || sessionJson.getString(SessionUtil.USERNAME).equals("")) {
            return new Msg(2);
        }

        String username = sessionJson.getString(SessionUtil.USERNAME);

        Integer tagOrderId = json.getInteger("tagOrderId");

        if (qrCodeService.DeleteTagOrders(username, tagOrderId)) {
            return new Msg(0);
        }
        return new Msg(1);
    }

    @PostMapping("/CheckTag")
    public Msg CheckTag(@RequestBody JSONObject json) {

        Long tag = json.getLong("Tag");
        if (qrCodeService.CheckTag(tag)) {

            return new Msg(0, fireworkGroupRepository.existsById(tag));
        }
        return new Msg(1);
    }

    @PostMapping("/GetUserList")
    public Msg GetUserList(@RequestBody JSONObject json) {

        JSONObject sessionJson = SessionUtil.getAuth();
        if (sessionJson == null || sessionJson.getString(SessionUtil.USERNAME).equals("")) {
            return new Msg(2);
        }

        String username = sessionJson.getString(SessionUtil.USERNAME);
        Integer pageInd = json.getInteger("pageInd") - 1;
        Integer pageSize = json.getInteger("pageSize");

        UserListDto userListDto = qrCodeService.GetUserList(username, pageInd, pageSize);
        if (userListDto != null) {

            return new Msg(0, userListDto);
        }
        return new Msg(1);
    }

    @PostMapping("/DeleteUser")
    public Msg DeleteUser(@RequestBody JSONObject json) {

        JSONObject sessionJson = SessionUtil.getAuth();
        if (sessionJson == null || sessionJson.getString(SessionUtil.USERNAME).equals("")) {
            return new Msg(2);
        }

        String username = sessionJson.getString(SessionUtil.USERNAME);

        Integer userId = json.getInteger("userId");

        if (qrCodeService.DeleteUsers(username, userId)) {

            return new Msg(0);
        }
        return new Msg(1);
    }

    @PostMapping("/AuthUser")
    public Msg AuthUser(@RequestBody JSONObject json) {

        JSONObject sessionJson = SessionUtil.getAuth();
        if (sessionJson == null || sessionJson.getString(SessionUtil.USERNAME).equals("")) {
            return new Msg(2);
        }

        String username = sessionJson.getString(SessionUtil.USERNAME);

        Integer userId = json.getInteger("userId");

        if (qrCodeService.AuthUsers(username, userId)) {

            return new Msg(0);
        }
        return new Msg(1);
    }

    @PostMapping("/BlockUser")
    public Msg BlockUser(@RequestBody JSONObject json) {

        JSONObject sessionJson = SessionUtil.getAuth();
        if (sessionJson == null || sessionJson.getString(SessionUtil.USERNAME).equals("")) {
            return new Msg(2);
        }

        String username = sessionJson.getString(SessionUtil.USERNAME);

        Integer userId = json.getInteger("userId");

        if (qrCodeService.BlockUsers(username, userId)) {

            return new Msg(0);
        }
        return new Msg(1);
    }

    @PostMapping("/UnBlockUser")
    public Msg UnBlockUser(@RequestBody JSONObject json) {

        JSONObject sessionJson = SessionUtil.getAuth();
        if (sessionJson == null || sessionJson.getString(SessionUtil.USERNAME).equals("")) {
            return new Msg(2);
        }

        String username = sessionJson.getString(SessionUtil.USERNAME);

        Integer userId = json.getInteger("userId");

        if (qrCodeService.UnBlockUsers(username, userId)) {

            return new Msg(0);
        }
        return new Msg(1);
    }
}
