package com.fireworklab.backend.controller;

import com.alibaba.fastjson.JSONObject;
import com.fireworklab.backend.dto.FireworkGroupDto;
import com.fireworklab.backend.entity.FireworkGroup;
import com.fireworklab.backend.repository.FireworkGroupRepository;
import com.fireworklab.backend.repository.TagRepository;
import com.fireworklab.backend.utils.msg.Msg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FireworkController {

    private FireworkGroupRepository fireworkGroupRepository;

    private TagRepository tagRepository;

    @Autowired
    public void setFireworkGroupRepository(FireworkGroupRepository fireworkGroupRepository) {
        this.fireworkGroupRepository = fireworkGroupRepository;
    }

    @Autowired
    public void setTagRepository(TagRepository tagRepository) {
        this.tagRepository = tagRepository;
    }

    @PostMapping("/SetFireworkGroup")
    public Msg SetFireworkGroup(@RequestBody JSONObject json) {

        FireworkGroup fireworkGroup = FireworkGroupDto.GetFireworkGroupDto(json).ToFireworkGroup();

        if (!tagRepository.existsById(fireworkGroup.getTag())) {

            return new Msg(1);
        }

        try {
            fireworkGroupRepository.save(fireworkGroup);
        } catch (Exception e){

            return new Msg(1);
        }

        return new Msg(0);
    }

    @PostMapping("/GetFireworkGroup")
    public Msg GetFireworkGroup(@RequestBody JSONObject json) {
        FireworkGroup fireworkGroup = fireworkGroupRepository.findByTag(json.getLong("Tag"));
        if (fireworkGroup == null) {
            return new Msg(1);
        }
        return new Msg(0, FireworkGroupDto.GetFireworkGroupDto(fireworkGroup));
    }
}
