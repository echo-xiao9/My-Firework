package com.fireworklab.backend.repository;

import com.fireworklab.backend.entity.FireworkBase;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FireworkBaseRepository extends JpaRepository<FireworkBase, Long> {
}
