package com.fireworklab.backend.repository;

import com.fireworklab.backend.entity.QrCodeUser;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QrCodeUserRepository extends JpaRepository<QrCodeUser, Integer> {

    QrCodeUser getByUsername (String username);

    boolean existsByUsername (String username);

}
