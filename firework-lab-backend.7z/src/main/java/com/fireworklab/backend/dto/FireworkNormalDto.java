package com.fireworklab.backend.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fireworklab.backend.entity.FireworkColorType;
import com.fireworklab.backend.entity.FireworkType;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class FireworkNormalDto extends FireworkBaseDto{

    @JsonProperty("FireworkColor")
    private FireworkColorType FireworkColor;

    @JsonProperty("InitialVelocity")
    private Double InitialVelocity;

    @JsonProperty("Radius")
    private Double Radius;

    public FireworkNormalDto(FireworkType type, Double x, Double y, Double z, FireworkColorType fireworkColor, Double initialVelocity, Double radius) {
        super(type, x, y, z);
        FireworkColor = fireworkColor;
        InitialVelocity = initialVelocity;
        Radius = radius;
    }
}
