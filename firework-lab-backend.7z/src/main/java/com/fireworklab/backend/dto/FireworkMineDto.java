package com.fireworklab.backend.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fireworklab.backend.entity.FireworkType;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class FireworkMineDto extends FireworkBaseDto{

    @JsonProperty("InitialVelocity")
    private Double InitialVelocity;

    public FireworkMineDto(FireworkType type, Double x, Double y, Double z, Double initialVelocity) {
        super(type, x, y, z);
        InitialVelocity = initialVelocity;
    }
}
