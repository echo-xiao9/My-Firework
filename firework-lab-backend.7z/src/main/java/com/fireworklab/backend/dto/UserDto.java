package com.fireworklab.backend.dto;

import com.fireworklab.backend.entity.QrCodeUserType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UserDto {

    private Integer id;
    private String username;
    private QrCodeUserType userType;
    private String message;
}
