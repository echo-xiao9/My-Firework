package com.fireworklab.backend.serviceImpl;

import com.fireworklab.backend.dto.TagOrderDto;
import com.fireworklab.backend.dto.TagOrderListDto;
import com.fireworklab.backend.dto.UserDto;
import com.fireworklab.backend.dto.UserListDto;
import com.fireworklab.backend.entity.*;
import com.fireworklab.backend.repository.QrCodeUserRepository;
import com.fireworklab.backend.repository.TagOrderRepository;
import com.fireworklab.backend.repository.TagRepository;
import com.fireworklab.backend.service.QrCodeService;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class QrCodeServiceImpl implements QrCodeService {

    private static final int QrCodeSize = 260;

    private QrCodeUserRepository qrCodeUserRepository;

    private TagOrderRepository tagOrderRepository;

    private TagRepository tagRepository;

    @Autowired
    public void setQrCodeUserRepository(QrCodeUserRepository qrCodeUserRepository) {
        this.qrCodeUserRepository = qrCodeUserRepository;
    }

    @Autowired
    public void setTagOrderRepository(TagOrderRepository tagOrderRepository) {
        this.tagOrderRepository = tagOrderRepository;
    }

    @Autowired
    public void setTagRepository(TagRepository tagRepository) {
        this.tagRepository = tagRepository;
    }

    @Override
    public boolean Register (String username, String password, String message) {

        if (username.length() == 0 || password.length() == 0) {
            return false;
        }

        if (qrCodeUserRepository.existsByUsername(username)) {
            return false;
        }

        QrCodeUser qrCodeUser = new QrCodeUser();
        qrCodeUser.setUsername(username);
        qrCodeUser.setPassword(password);
        qrCodeUser.setUserType(QrCodeUserType.PENDING);

        UserMessage userMessage = new UserMessage();
        userMessage.setMessage(message);
        userMessage.setQrCodeUser(qrCodeUser);
        qrCodeUser.setUserMessage(userMessage);

        qrCodeUserRepository.save(qrCodeUser);

        return true;
    }

    @Override
    public boolean Login (String username, String password) {

        try {

            QrCodeUser qrCodeUser = qrCodeUserRepository.getByUsername(username);
            if (qrCodeUser.getUserType() == QrCodeUserType.PENDING || qrCodeUser.getUserType() == QrCodeUserType.FORBIDDEN) {
                return false;
            }
            return qrCodeUser.getPassword().equals(password);
        } catch (Exception e) {

            return false;
        }
    }

    @Override
    public boolean CheckRoot (String username) {

        try {

            QrCodeUser qrCodeUser = qrCodeUserRepository.getByUsername(username);
            return qrCodeUser.getUserType() == QrCodeUserType.MANAGER;
        } catch (Exception e) {

            return false;
        }
    }

    @Override
    public Integer GenerateRandomTags (String username, Integer number) {

        Integer res = 0;
        QrCodeUser qrCodeUser;

        qrCodeUser = qrCodeUserRepository.getByUsername(username);
        if (qrCodeUser == null) {
            return res;
        }

        TagOrder tagOrder = new TagOrder();
        List<Tag> tagList = new ArrayList<>();

        tagOrder.setQrCodeUser(qrCodeUser);
        tagOrder.setDate(new Date());

        for (int i = 0; i < number; ++i) {

            Tag tag = new Tag();
            tag.setTagOrder(tagOrder);
            tagList.add(tag);
        }
        tagOrder.setTagList(tagList);

        boolean flag;
        do {
            SecureRandom secureRandom = new SecureRandom();

            for (Tag tag : tagList) {

                tag.setId(secureRandom.nextInt(999999999) + secureRandom.nextInt(899999999) * 1000000000L + 100000000000000000L);
            }

            try {
                res = tagOrderRepository.save(tagOrder).getId();
                flag = false;

            } catch (Exception e) {

                flag = true;
            }

        } while (flag);

        return res;
    }

    @Override
    public List<BitMatrix> GetImageMatrix (String username, Integer tagOrderId) {

        TagOrder tagOrder;
        try {
            tagOrder = tagOrderRepository.getById(tagOrderId);
            if (!tagOrder.getQrCodeUser().getUsername().equals(username)) {
                return null;
            }

        } catch (Exception e) {
            return null;
        }

        List<BitMatrix> bitMatrices = new ArrayList<>();

        try {

            for (Tag tag : tagOrder.getTagList()) {

                bitMatrices.add(new QRCodeWriter().encode(tag.getId().toString(), BarcodeFormat.QR_CODE, QrCodeSize, QrCodeSize));
            }
        }catch (Exception e) {

            return null;
        }


        return bitMatrices;
    }

    @Override
    public TagOrderListDto GetTagOrders (String username, Integer pageInd, Integer pageSize) {

        try {

            QrCodeUser qrCodeUser = qrCodeUserRepository.getByUsername(username);
            Page<TagOrder> tagOrders;
            if (qrCodeUser.getUserType() == QrCodeUserType.MANAGER) {
                tagOrders = tagOrderRepository.findAll(PageRequest.of(pageInd, pageSize));
            }
            else if (qrCodeUser.getUserType() == QrCodeUserType.NORMAL) {
                tagOrders = tagOrderRepository.findAllByQrCodeUser(qrCodeUser, PageRequest.of(pageInd, pageSize));
            }
            else  return null;

            TagOrderListDto tagOrderListDto = new TagOrderListDto();
            List<TagOrderDto> tagOrderList = new ArrayList<>();
            for (TagOrder tagOrder : tagOrders) {
                TagOrderDto tagOrderDto = new TagOrderDto(tagOrder.getId(), tagOrder.getDate(), tagOrder.getQrCodeUser().getUsername(), tagOrder.getTagList().size());
                tagOrderList.add(tagOrderDto);
            }

            tagOrderListDto.setTagOrders(tagOrderList);
            tagOrderListDto.setPageNumber(tagOrders.getTotalPages());
            return tagOrderListDto;

        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public boolean DeleteTagOrders (String username, Integer tagOrderId) {

        try {

            TagOrder tagOrder = tagOrderRepository.getById(tagOrderId);
            QrCodeUser qrCodeUser = tagOrder.getQrCodeUser();

            if (!qrCodeUser.getUsername().equals(username) && qrCodeUserRepository.getByUsername(username).getUserType() != QrCodeUserType.MANAGER) {
                return false;
            }
            tagOrderRepository.delete(tagOrder);
            return true;

        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public boolean CheckTag (Long tag) {

        return tagRepository.existsById(tag);
    }

    @Override
    public UserListDto GetUserList (String username, Integer pageInd, Integer pageSize) {

        try {

            QrCodeUser qrCodeUser = qrCodeUserRepository.getByUsername(username);
            if (qrCodeUser.getUserType() != QrCodeUserType.MANAGER) {
                return null;
            }

            Page<QrCodeUser> qrCodeUserList = qrCodeUserRepository.findAll(PageRequest.of(pageInd, pageSize));
            UserListDto userListDto = new UserListDto();
            List<UserDto> userDtoList = new ArrayList<>();

            for (QrCodeUser qrCodeUser1 : qrCodeUserList) {

                userDtoList.add(new UserDto(qrCodeUser1.getId(), qrCodeUser1.getUsername(), qrCodeUser1.getUserType(), qrCodeUser1.getUserMessage().getMessage()));
            }
            userListDto.setUserList(userDtoList);
            userListDto.setPageNumber(qrCodeUserList.getTotalPages());

            return userListDto;

        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public boolean DeleteUsers (String username, Integer userId) {

        try {
            if(qrCodeUserRepository.getByUsername(username).getUserType() != QrCodeUserType.MANAGER) {
                return false;
            }
            if(qrCodeUserRepository.getById(userId).getUserType() != QrCodeUserType.PENDING) {
                return false;
            }
            qrCodeUserRepository.deleteById(userId);
        } catch (Exception e) {

            return false;
        }
        return true;
    }

    @Override
    public boolean AuthUsers (String username, Integer userId) {

        try {
            if(qrCodeUserRepository.getByUsername(username).getUserType() != QrCodeUserType.MANAGER) {
                return false;
            }
            QrCodeUser qrCodeUser = qrCodeUserRepository.getById(userId);
            if (qrCodeUser.getUserType() != QrCodeUserType.PENDING) {
                return false;
            }
            qrCodeUser.setUserType(QrCodeUserType.NORMAL);
            qrCodeUserRepository.save(qrCodeUser);
        } catch (Exception e) {

            return false;
        }
        return true;
    }

    @Override
    public boolean BlockUsers (String username, Integer userId) {

        try {
            if(qrCodeUserRepository.getByUsername(username).getUserType() != QrCodeUserType.MANAGER) {
                return false;
            }
            QrCodeUser qrCodeUser = qrCodeUserRepository.getById(userId);
            if (qrCodeUser.getUserType() != QrCodeUserType.NORMAL) {
                return false;
            }
            qrCodeUser.setUserType(QrCodeUserType.FORBIDDEN);
            qrCodeUserRepository.save(qrCodeUser);
        } catch (Exception e) {

            return false;
        }
        return true;
    }

    @Override
    public boolean UnBlockUsers (String username, Integer userId) {

        try {
            if(qrCodeUserRepository.getByUsername(username).getUserType() != QrCodeUserType.MANAGER) {
                return false;
            }
            QrCodeUser qrCodeUser = qrCodeUserRepository.getById(userId);
            if (qrCodeUser.getUserType() != QrCodeUserType.FORBIDDEN) {
                return false;
            }
            qrCodeUser.setUserType(QrCodeUserType.NORMAL);
            qrCodeUserRepository.save(qrCodeUser);
        } catch (Exception e) {

            return false;
        }
        return true;
    }
}
